api 增强util的api

# try catch 包装，忽略模式

减少大段语法噪音，类似vbs模式

# sql dsl模式包装 链式包装

#  异步变同步包装

# 其他减少语法噪音的包装

# debug log warp..console.log
开发人员，全栈
dba数据库存储管理
系統管理
数据或业务分析师



sss  com type..
2ppl...or small grp is better.... no one can zihwi ni ,,ni gaz zosh mastr....


sss lan type...   net php  small grp use tech....   not java..too many ppl.


系統管理員
$55，271
数据库管理员


###ss prj crt and run mantimt  ..not only dev
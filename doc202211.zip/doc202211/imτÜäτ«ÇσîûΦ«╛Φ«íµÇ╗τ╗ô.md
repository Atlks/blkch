im的简化设计总结

smp lan::lang to scrpt lan is bettr...
smp db：：db使用mongodb
token使用客户端token。。不是tokenid 服务端模式

smp design,,no mvc...

mlt prj>>> one prj mode..smp prj zo ok


dsktp app use chrome no head mode..
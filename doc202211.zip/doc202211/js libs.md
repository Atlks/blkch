js libs

多选控件 + 搜索
Basic usage | Select2 - The jQuery replacement for select boxes
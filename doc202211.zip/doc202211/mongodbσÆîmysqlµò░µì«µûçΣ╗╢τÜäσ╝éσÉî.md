mongodb和mysql数据文件的异同

C:\Program Files\MongoDB\Server\6.0\data



miraia10
是每个表一个文件,but idx data together fil


mongo is dt idx splt ,not tgthrough


数据存储的本质是存到表。分表很重要.db jst container..not impt db..
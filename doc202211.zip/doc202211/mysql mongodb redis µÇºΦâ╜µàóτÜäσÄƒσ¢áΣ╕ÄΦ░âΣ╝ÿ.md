mysql mongodb redis 性能慢的原因与调优

# 去除事务机制 与事务日志 隔离级别调低

# 分表模式  降低表锁
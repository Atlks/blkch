nodejs  useful lib



# nodemon
问题：在 node 环境中每次修改 JavaScript 文件后都需要重新执行该文件才能看到效果。
通过 nodemon 可以解决此烦恼，它是命令工具软件包，可以监控文件变化，自动重新执行文件。
npm install nodemon@2.0.7 -g
nodemon app.js
 


# util.promise  ,,bluebird promise lib

# mongodb ,rds lib suport await

# sqlt lib not spt awt..only can uti.proms to convt..

# mlt process lib


# 7. lodash util lib
 






Lodash 减少数组、数字、对象、字符串等工作的麻烦，它让 JS 变得更容易。

# common db api ..orm API
Sequelize是一个易于使用和基于承诺的Node.js ORM工具，适用于Postgres，MySQL，MariaDB，SQLite，DB2，Microsoft SQL Server和Snowflake。它具有可靠的事务支持、关系、急切和延迟加载、读取复制等功能。
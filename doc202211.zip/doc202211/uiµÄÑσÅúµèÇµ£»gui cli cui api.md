﻿
ui接口技术gui cli cui api


目录
1.	Command User Interface，命令行用户交	1
2.	CLI - 命令行界面(Command Line Interface)	1
3.	GUI 应用程序往往是基于 CLI 工具的	1
1.	TUI - 终端用户界面(Terminal User Interface)（也称为 基于文本的用户界面(Text-based User Interface)）	2

1. 父概念ui。。。
类似概念gui cli api  
深入概念。。。
2. Command User Interface，命令行用户交
3. CLI - 命令行界面(Command Line Interface)
CLI 基本上是一个接受输入来执行某种功能的命令行程序。基本上，任何可以在终端中通过命令使用的应用程序都属于这一类。
你可能会有一个基于 GUI 的应用程序来完成同样的任务，但命令可以让你更精细地访问这些功能。在一些情况下，你会发现 GUI 应用程序也会用命令（在它们的代码中使用）与操作系统交互。

4. GUI 应用程序往往是基于 CLI 工具的
许多流行的 GUI 应用程序往往是基于 CLI 工具的。以Handbrake 为例。这是一个流行的开源媒体转换器，它底层使用的是 FFMPEG 命令行工具。


1. TUI - 终端用户界面(Terminal User Interface)（也称为 基于文本的用户界面(Text-based User Interface)）
这是三者中最不常见的名词。TUI 基本上部分是 GUI，部分是 CLI。糊涂了吗？让我为你解释一下。
你已经知道，早期的计算机使用 CLI。在实际的 GUI 出现之前，基于文本的用户界面在终端中提供了一种非常基本的图形交互。你会有更多的视觉效果，也可以使用鼠标和键盘与应用程序进行交互。

TUI 的应用虽然不是那么常见，但你还是有一些的。基于终端的 Web 浏览器是 TUI 程序的好例子。基于终端的游戏也属于这一类。


TUI 应用程序通常也被认为是 CLI 应用程序，因为它们被限制在终端上。在我看来，你是否认为它们与 CLI 不同，这取决于你。

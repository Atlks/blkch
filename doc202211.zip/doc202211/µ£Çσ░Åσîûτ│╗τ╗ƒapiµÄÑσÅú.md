最小化系统api接口

sql接口。
适当风化下by id
by named
by coditon  c1,22,c233, c3，55，c455,c5,66
by where expression
update
del
add


mongodb api
rds api

标准api 统一的数据库接口

jdbc，pdo net 对比


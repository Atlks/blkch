高并发 多库模式下sqlte和 mysql对比

maria db v10 貌似每个库占地比也不大。。和sqlt差不多。。

